Please note that this Pytorch code serves only as a demonstration of our method proposed in the paper "Learning Dynamic Interpolation for Extremely Sparse Light Fields with Wide Baselines" with paper ID 2767. The demo synthesizes 3 novel views between 2 input ones which are sampled along a scanline;

1. Dependences:
	Python 3.6.12
	Pytorch 1.7.1
	scipy
	h5py
	skimage
	lmdb
	pickle
	tqdm
	Pillow
	opencv
	torchnet
	

2. Contents of folders:
	1) data: filename lists of RGB images;
	2) experiments: experimental setting files;
	3) figures;
	4) lib: library:
		(1) config: configuration files;
		(2) core: the training functions;
		(3) dataset: dataset and dataloader file;
		(4) models: model files;
		(5) utils.
	5) log;
	6) output: outputs of training model;
	7) pretrain: pretrained model of semantic segmentation network (HRNetV2-W48)；
	8) RGB: a test data from ICVL dataset;
	9) tools: main function;

3. Usage:
 
Inference: 
	sh run.sh

4. Note:
Due to the limited size of supplementary material, we only provide test code with one test sample from ICVL dataset. The proposed method needs a pretrain HRNet (nearly 200M) for training.